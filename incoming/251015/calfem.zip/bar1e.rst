bar1e
^^^^^

.. index:: bar1e

:Purpose:

    Compute element stiffness matrix for a one dimensional bar element.

    .. figure:: images/bar1e_1.png
        :align: center
        :width: 70%
    

:Syntax:

.. only:: matlab

    .. code-block:: matlab

        Ke = bar1e(ex, ep)
        [Ke, fe] = bar1e(ex, ep, eq)

.. only:: python

    .. code-block:: python

        Ke = cfc.bar1e(ex, ep)
        Ke, fe = cfc.bar1e(ex, ep, eq)

:Description:

    :code:`bar1e` provides the element stiffness matrix :math:`\bar{\mathbf{K}}^e` for a one dimensional bar element.
    The input variables

    :code:`ex`:math:`= [x_1 \;\; x_2]`
    :math:`\qquad` 
    :code:`ep`:math:`=  [E \; A]`

    supply the element nodal coordinates :math:`x_1` and :math:`x_2`, the modulus of elasticity :math:`E`,
    and the cross section area :math:`A`.

    The element load vector :math:`\bar{\mathbf{f}}_l^e` can also be computed if a uniformly distributed load is applied to the element.
    The optional input variable

    :code:`eq`:math:`= [q_{\bar{x}}]`

    contains the distributed load per unit length, :math:`q_{\bar{x}}`.

    .. figure:: images/bar1e_2.png
        :align: center
        :width: 70%

:Theory:

    The element stiffness matrix :math:`\bar{\mathbf{K}}^e`, stored in :code:`Ke`, is computed according to

    .. math::

        \bar{\mathbf{K}}^e = \frac{D_{EA}}{L}
        \begin{bmatrix}
        1 & -1 \\
        -1 & 1
        \end{bmatrix}

    where the axial stiffness :math:`D_{EA}` and the length :math:`L` are given by

    .. math::

        D_{EA} = EA; \quad L = x_2 - x_1

    The element load vector :math:`\bar{\mathbf{f}}_l^e`, stored in :code:`fe`, is computed according to

    .. math::

        \bar{\mathbf{f}}_l^e = \frac{q_{\bar{x}} L}{2}
        \begin{bmatrix}
        1 \\
        1
        \end{bmatrix}